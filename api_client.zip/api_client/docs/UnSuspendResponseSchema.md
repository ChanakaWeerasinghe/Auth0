# MdesForMerchants.UnSuspendResponseSchema

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**responseHost** | **String** | The host that originated the request. Future calls in the same conversation may be routed to this host.  | [optional] 
**responseId** | **String** | Unique identifier for the response.  | [optional] 
**tokens** | [**[TokenForLCM]**](TokenForLCM.md) |  | [optional] 


