# MdesForMerchants.AssetResponseSchema

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**mediaContents** | [**[MediaContent]**](MediaContent.md) |  | [optional] 


