# MdesForMerchants.GetTokenResponseSchema

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**responseId** | **String** | Unique identifier for the response.  | [optional] 
**token** | [**Token**](Token.md) |  | [optional] 
**tokenDetail** | [**TokenDetail**](TokenDetail.md) |  | [optional] 
**errors** | [**[Error]**](Error.md) |  | [optional] 


