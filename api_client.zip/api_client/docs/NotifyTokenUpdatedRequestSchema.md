# MdesForMerchants.NotifyTokenUpdatedRequestSchema

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**responseHost** | **String** | The host that originated the request. Future calls in the same conversation should be routed to this host.  | 
**requestId** | **String** | Unique identifier for the request.  | 
**encryptedPayload** | [**EncryptedPayload**](EncryptedPayload.md) |  | 


