# MdesForMerchants.NotifyTokenEncryptedPayload

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**tokens** | [**[Token]**](Token.md) |  | [optional] 


