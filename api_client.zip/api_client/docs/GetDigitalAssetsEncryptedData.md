# MdesForMerchants.GetDigitalAssetsEncryptedData

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**accountNumber** | **String** | The Primary Account Number for the transaction - this is the token PAN. &lt;br&gt;__Min Length: 9__ &lt;br&gt;__Max Length: 19__  | [optional] 


