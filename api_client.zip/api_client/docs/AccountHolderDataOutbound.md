# MdesForMerchants.AccountHolderDataOutbound

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**accountHolderName** | **String** | __(OPTIONAL)__ The name of the cardholder&lt;br&gt; __Max Length:27__  | [optional] 
**accountHolderAddress** | [**BillingAddress**](BillingAddress.md) |  | [optional] 
**accountHolderEmailAddress** | **String** | __(OPTIONAL)__ The e-mail address of the Account Holder&lt;br&gt; __Max Length:320__  | [optional] 
**accountHolderMobilePhoneNumber** | [**PhoneNumber**](PhoneNumber.md) |  | [optional] 


